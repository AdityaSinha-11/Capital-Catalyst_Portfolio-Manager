import { useState, useEffect } from 'react';
import { ChartData } from '@/types/stock';

// Generate mock historical data
const generateMockChartData = (days: number, basePrice: number = 100): ChartData[] => {
  const data: ChartData[] = [];
  let currentPrice = basePrice;
  const now = Date.now();
  
  for (let i = days; i >= 0; i--) {
    const timestamp = now - (i * 24 * 60 * 60 * 1000);
    
    // Generate realistic OHLC data
    const volatility = 0.02;
    const change = (Math.random() - 0.5) * volatility * currentPrice;
    
    const open = currentPrice;
    const trend = Math.sin(i / 10) * 0.001 * currentPrice; // Add some trend
    const close = open + change + trend;
    
    const high = Math.max(open, close) + Math.random() * 0.01 * currentPrice;
    const low = Math.min(open, close) - Math.random() * 0.01 * currentPrice;
    const volume = Math.floor(Math.random() * 1000000 + 500000);
    
    data.push({
      timestamp,
      open: Math.max(open, 1),
      high: Math.max(high, 1),
      low: Math.max(low, 1),
      close: Math.max(close, 1),
      volume
    });
    
    currentPrice = close;
  }
  
  return data.sort((a, b) => a.timestamp - b.timestamp);
};

export const useChartData = (symbol: string) => {
  const [data, setData] = useState<{[key: string]: ChartData[]}>({});
  const [isLoading, setIsLoading] = useState(false);

  const intervals = {
    '1D': 1,
    '1W': 7,
    '1M': 30,
    '3M': 90,
    '1Y': 365,
    'MAX': 365 * 3
  };

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      
      // In real implementation, fetch from Yahoo Finance API
      // For now, generate mock data for all intervals
      const newData: {[key: string]: ChartData[]} = {};
      
      Object.entries(intervals).forEach(([interval, days]) => {
        // Use different base prices for different stocks
        const basePrice = symbol === 'AAPL' ? 150 : 
                         symbol === 'TSLA' ? 200 : 
                         symbol === 'GOOGL' ? 140 : 100;
        
        newData[interval] = generateMockChartData(days, basePrice);
      });
      
      setData(newData);
      setIsLoading(false);
    };

    if (symbol) {
      loadData();
    }
  }, [symbol]);

  // Simulate real-time updates for 1D chart
  useEffect(() => {
    if (!data['1D']) return;

    const interval = setInterval(() => {
      setData(prev => {
        if (!prev['1D'] || prev['1D'].length === 0) return prev;
        
        const lastPoint = prev['1D'][prev['1D'].length - 1];
        const change = (Math.random() - 0.5) * 0.01 * lastPoint.close;
        
        const updatedData = [...prev['1D']];
        updatedData[updatedData.length - 1] = {
          ...lastPoint,
          close: Math.max(lastPoint.close + change, 1),
          high: Math.max(lastPoint.high, lastPoint.close + change),
          low: Math.min(lastPoint.low, lastPoint.close + change),
          volume: lastPoint.volume + Math.floor((Math.random() - 0.5) * 10000)
        };
        
        return {
          ...prev,
          '1D': updatedData
        };
      });
    }, 2000); // Update every 2 seconds

    return () => clearInterval(interval);
  }, [data['1D']]);

  return { data, isLoading, intervals: Object.keys(intervals) };
};