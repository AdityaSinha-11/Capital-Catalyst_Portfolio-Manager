import { useState, useEffect } from 'react';
import { Instrument } from '@/types/stock';
import { instrumentsApi } from '@/services/api';

export const useInstruments = () => {
  const [instruments, setInstruments] = useState<Instrument[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch instruments on component mount
  useEffect(() => {
    fetchInstruments();
  }, []);

  const fetchInstruments = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await instrumentsApi.getAll();
      setInstruments(response.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch instruments');
      console.error('Error fetching instruments:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const addInstrument = async (instrumentData: Omit<Instrument, 'id' | 'created_at' | 'updated_at'>) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await instrumentsApi.create(instrumentData);
      setInstruments(prev => [...prev, response.data]);
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add instrument');
      console.error('Error adding instrument:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const updateInstrument = async (id: number, updates: Partial<Instrument>) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await instrumentsApi.update(id, updates as any);
      setInstruments(prev => prev.map(instrument => 
        instrument.id === id ? { ...instrument, ...response.data } : instrument
      ));
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update instrument');
      console.error('Error updating instrument:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const deleteInstrument = async (id: number, cascade?: boolean) => {
    setIsLoading(true);
    setError(null);
    
    try {
      await instrumentsApi.delete(id, cascade);
      setInstruments(prev => prev.filter(instrument => instrument.id !== id));
    } catch (err) {
      // Extract the actual error message from the backend response
      let errorMessage = 'Failed to delete instrument';
      if (err && typeof err === 'object' && 'response' in err && err.response?.data?.error) {
        errorMessage = err.response.data.error;
      } else if (err instanceof Error) {
        errorMessage = err.message;
      }
      setError(errorMessage);
      console.error('Error deleting instrument:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const buyInstrument = async (id: number, data: { quantity: number; price: number; goal_id?: number }) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await instrumentsApi.buy(id, data);
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to buy instrument');
      console.error('Error buying instrument:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const sellInstrument = async (id: number, data: { quantity: number; price: number; goal_id?: number }) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await instrumentsApi.sell(id, data);
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to sell instrument');
      console.error('Error selling instrument:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    instruments,
    addInstrument,
    updateInstrument,
    deleteInstrument,
    buyInstrument,
    sellInstrument,
    isLoading,
    error,
    refetch: fetchInstruments
  };
}; 