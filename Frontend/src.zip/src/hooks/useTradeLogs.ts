import { useState, useEffect } from 'react';
import { TradeLog } from '@/types/stock';
import { tradeLogApi } from '@/services/api';

export const useTradeLogs = () => {
  const [tradeLogs, setTradeLogs] = useState<TradeLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch trade logs on component mount
  useEffect(() => {
    fetchTradeLogs();
  }, []);

  const fetchTradeLogs = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await tradeLogApi.getAll();
      setTradeLogs(response.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch trade logs');
      console.error('Error fetching trade logs:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const addTradeLog = async (tradeData: Omit<TradeLog, 'id' | 'created_at'>) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Note: Trade logs are now created automatically when buying/selling instruments
      // This function is kept for compatibility but trade logs should be created via buy/sell endpoints
      const newTrade: TradeLog = {
        ...tradeData,
        id: Date.now(),
        created_at: new Date().toISOString()
      };
      
      setTradeLogs(prev => [newTrade, ...prev]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add trade log');
      console.error('Error adding trade log:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    tradeLogs,
    addTradeLog,
    isLoading,
    error,
    refetch: fetchTradeLogs
  };
};