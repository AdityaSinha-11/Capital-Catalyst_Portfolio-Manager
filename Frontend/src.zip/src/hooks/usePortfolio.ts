import { useState, useEffect } from 'react';
import { Stock, PortfolioSummary } from '@/types/stock';

// Mock data for demonstration
const mockStocks: Stock[] = [
  {
    id: 1,
    symbol: "AAPL",
    name: "Apple Inc.",
    type: "STOCK",
    quantity: 10,
    purchase_price: 150.25,
    purchase_date: "2024-01-15",
    current_price: 175.43,
    change: 2.45,
    change_percent: 1.42,
    goal_id: 1
  },
  {
    id: 2,
    symbol: "TSLA",
    name: "Tesla, Inc.",
    type: "STOCK",
    quantity: 5,
    purchase_price: 220.80,
    purchase_date: "2024-02-01",
    current_price: 198.50,
    change: -5.20,
    change_percent: -2.55,
    goal_id: 2
  },
  {
    id: 3,
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    type: "STOCK",
    quantity: 3,
    purchase_price: 138.90,
    purchase_date: "2024-01-20",
    current_price: 142.15,
    change: 1.85,
    change_percent: 1.32,
    goal_id: 1
  },
  {
    id: 4,
    symbol: "HDFCMF",
    name: "HDFC Large Cap Fund",
    type: "MF",
    quantity: 100,
    purchase_price: 45.20,
    purchase_date: "2024-01-10",
    current_price: 47.80,
    change: 0.12,
    change_percent: 0.25,
    goal_id: 1
  },
  {
    id: 5,
    symbol: "GOLD",
    name: "Gold ETF",
    type: "GOLD",
    quantity: 2,
    purchase_price: 5800.00,
    purchase_date: "2024-01-25",
    current_price: 6050.00,
    change: 15.00,
    change_percent: 0.25,
    goal_id: 3
  }
];

export const usePortfolio = () => {
  const [stocks, setStocks] = useState<Stock[]>(mockStocks);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Calculate portfolio summary
  const calculateSummary = (stockList: Stock[]): PortfolioSummary => {
    const totalValue = stockList.reduce((sum, stock) => {
      return sum + (stock.current_price || stock.purchase_price) * stock.quantity;
    }, 0);

    const totalInvested = stockList.reduce((sum, stock) => {
      return sum + stock.purchase_price * stock.quantity;
    }, 0);

    const totalPnl = totalValue - totalInvested;
    const totalPnlPercent = totalInvested > 0 ? (totalPnl / totalInvested) * 100 : 0;

    const dayChange = stockList.reduce((sum, stock) => {
      return sum + (stock.change || 0) * stock.quantity;
    }, 0);

    const dayChangePercent = stockList.reduce((sum, stock) => {
      return sum + ((stock.change_percent || 0) / 100) * (stock.current_price || stock.purchase_price) * stock.quantity;
    }, 0);

    return {
      total_value: totalValue,
      total_invested: totalInvested,
      total_pnl: totalPnl,
      total_pnl_percent: totalPnlPercent,
      day_change: dayChange,
      day_change_percent: totalValue > 0 ? (dayChangePercent / totalValue) * 100 : 0
    };
  };

  const portfolioSummary = calculateSummary(stocks);

  // Add stock function
  const addStock = async (stockData: Omit<Stock, 'id'>) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // In real implementation, make API call to backend
      // const response = await fetch('/api/portfolio', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(stockData)
      // });
      
      // Mock implementation
      const newStock: Stock = {
        ...stockData,
        id: Date.now(), // Mock ID
        current_price: stockData.purchase_price * (1 + (Math.random() - 0.5) * 0.1),
        change: (Math.random() - 0.5) * 10,
        change_percent: (Math.random() - 0.5) * 5
      };
      
      setStocks(prev => [...prev, newStock]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add stock');
    } finally {
      setIsLoading(false);
    }
  };

  // Delete stock function
  const deleteStock = async (id: number) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // In real implementation, make API call to backend
      // await fetch(`/api/portfolio/${id}`, { method: 'DELETE' });
      
      // Mock implementation
      setStocks(prev => prev.filter(stock => stock.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete stock');
    } finally {
      setIsLoading(false);
    }
  };

  // Update stock prices (simulate real-time updates)
  useEffect(() => {
    const interval = setInterval(() => {
      setStocks(prev => prev.map(stock => ({
        ...stock,
        current_price: stock.current_price! * (1 + (Math.random() - 0.5) * 0.02),
        change: (Math.random() - 0.5) * 10,
        change_percent: (Math.random() - 0.5) * 5
      })));
    }, 5000); // Update every 5 seconds for demo

    return () => clearInterval(interval);
  }, []);

  return {
    stocks,
    portfolioSummary,
    addStock,
    deleteStock,
    isLoading,
    error
  };
};