import { useState, useEffect } from 'react';
import { Goal } from '@/types/stock';
import { goalsApi } from '@/services/api';

export const useGoals = () => {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch goals on component mount
  useEffect(() => {
    fetchGoals();
  }, []);

  const fetchGoals = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await goalsApi.getAll();
      const goalsData = response.data.map((goal: { id: number; name: string; target_amount: number; created_at: string }) => ({
        ...goal,
        current_amount: 0 // This will be calculated based on trade logs
      }));
      setGoals(goalsData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch goals');
      console.error('Error fetching goals:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const addGoal = async (goalData: Omit<Goal, 'id' | 'current_amount' | 'created_at'>) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await goalsApi.create({
        name: goalData.name,
        target_amount: goalData.target_amount
      });
      
      const newGoal: Goal = {
        ...response.data,
        current_amount: 0
      };
      
      setGoals(prev => [...prev, newGoal]);
      return newGoal;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add goal');
      console.error('Error adding goal:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const updateGoal = async (id: number, updates: Partial<Goal>) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await goalsApi.update(id, {
        name: updates.name!,
        target_amount: updates.target_amount!
      });
      
      setGoals(prev => prev.map(goal => 
        goal.id === id ? { ...goal, ...response.data } : goal
      ));
      return response.data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update goal');
      console.error('Error updating goal:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const deleteGoal = async (id: number) => {
    setIsLoading(true);
    setError(null);
    
    try {
      await goalsApi.delete(id);
      setGoals(prev => prev.filter(goal => goal.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete goal');
      console.error('Error deleting goal:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    goals,
    addGoal,
    updateGoal,
    deleteGoal,
    isLoading,
    error,
    refetch: fetchGoals
  };
};