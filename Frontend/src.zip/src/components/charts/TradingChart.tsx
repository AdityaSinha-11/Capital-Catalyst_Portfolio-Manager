import { useState } from 'react';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChartData } from '@/types/stock';
import { TrendingUp, TrendingDown, Volume2, Activity } from 'lucide-react';

interface TradingChartProps {
  symbol: string;
  data: ChartData[];
  selectedInterval: string;
  onIntervalChange: (interval: string) => void;
  intervals: string[];
}

export const TradingChart = ({ 
  symbol, 
  data, 
  selectedInterval, 
  onIntervalChange, 
  intervals 
}: TradingChartProps) => {
  const [chartType, setChartType] = useState<'line' | 'area'>('line');
  const [showVolume, setShowVolume] = useState(true);

  if (!data || data.length === 0) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-96">
          <div className="text-center">
            <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Loading chart data...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const formatData = data.map(point => ({
    ...point,
    date: new Date(point.timestamp).toLocaleDateString(),
    time: new Date(point.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    formattedDate: selectedInterval === '1D' 
      ? new Date(point.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      : new Date(point.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' })
  }));

  const currentPrice = data[data.length - 1]?.close || 0;
  const previousPrice = data[data.length - 2]?.close || currentPrice;
  const change = currentPrice - previousPrice;
  const changePercent = previousPrice !== 0 ? (change / previousPrice) * 100 : 0;
  const isPositive = change >= 0;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length > 0) {
      const data = payload[0].payload;
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="font-medium text-sm mb-2">{label}</p>
          <div className="space-y-1 text-xs">
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Open:</span>
              <span>${data.open?.toFixed(2)}</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">High:</span>
              <span className="text-success">${data.high?.toFixed(2)}</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Low:</span>
              <span className="text-destructive">${data.low?.toFixed(2)}</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Close:</span>
              <span className="font-medium">${data.close?.toFixed(2)}</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Volume:</span>
              <span>{data.volume?.toLocaleString()}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div>
              <CardTitle className="text-2xl font-bold font-mono text-primary">
                {symbol}
              </CardTitle>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-2xl font-bold">
                  ${currentPrice.toFixed(2)}
                </span>
                <div className={`flex items-center gap-1 ${isPositive ? 'text-success' : 'text-destructive'}`}>
                  {isPositive ? (
                    <TrendingUp className="h-4 w-4" />
                  ) : (
                    <TrendingDown className="h-4 w-4" />
                  )}
                  <span className="font-medium">
                    {isPositive ? '+' : ''}{change.toFixed(2)}
                  </span>
                  <span className="text-sm">
                    ({isPositive ? '+' : ''}{changePercent.toFixed(2)}%)
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Chart Type Toggle */}
            <div className="flex bg-secondary rounded-lg p-1">
              <Button
                variant={chartType === 'line' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setChartType('line')}
                className="h-8 px-3"
              >
                Line
              </Button>
              <Button
                variant={chartType === 'area' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setChartType('area')}
                className="h-8 px-3"
              >
                Area
              </Button>
            </div>

            {/* Volume Toggle */}
            <Button
              variant={showVolume ? 'default' : 'outline'}
              size="sm"
              onClick={() => setShowVolume(!showVolume)}
              className="h-8 gap-1"
            >
              <Volume2 className="h-3 w-3" />
              Volume
            </Button>
          </div>
        </div>

        {/* Time Interval Selector */}
        <div className="flex flex-wrap gap-1 mt-4">
          {intervals.map((interval) => (
            <Button
              key={interval}
              variant={selectedInterval === interval ? 'default' : 'outline'}
              size="sm"
              onClick={() => onIntervalChange(interval)}
              className="h-8 px-3"
            >
              {interval}
            </Button>
          ))}
        </div>
      </CardHeader>

      <CardContent className="p-0">
        <div className="space-y-4">
          {/* Main Price Chart */}
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              {chartType === 'line' ? (
                <LineChart data={formatData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="formattedDate"
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                    tickFormatter={(value) => `$${value.toFixed(0)}`}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Line
                    type="monotone"
                    dataKey="close"
                    stroke={isPositive ? "hsl(var(--success))" : "hsl(var(--destructive))"}
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 4, stroke: "hsl(var(--primary))", strokeWidth: 2 }}
                  />
                  <ReferenceLine 
                    y={data[0]?.open} 
                    stroke="hsl(var(--muted-foreground))" 
                    strokeDasharray="2 2" 
                    opacity={0.5}
                  />
                </LineChart>
              ) : (
                <AreaChart data={formatData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="formattedDate"
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                    tickFormatter={(value) => `$${value.toFixed(0)}`}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="close"
                    stroke={isPositive ? "hsl(var(--success))" : "hsl(var(--destructive))"}
                    fill={isPositive ? "hsl(var(--success))" : "hsl(var(--destructive))"}
                    fillOpacity={0.1}
                    strokeWidth={2}
                  />
                  <ReferenceLine 
                    y={data[0]?.open} 
                    stroke="hsl(var(--muted-foreground))" 
                    strokeDasharray="2 2" 
                    opacity={0.5}
                  />
                </AreaChart>
              )}
            </ResponsiveContainer>
          </div>

          {/* Volume Chart */}
          {showVolume && (
            <div className="h-24 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={formatData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <XAxis 
                    dataKey="formattedDate"
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={10}
                    hide
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={10}
                    tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`}
                  />
                  <Bar
                    dataKey="volume"
                    fill="hsl(var(--muted))"
                    opacity={0.6}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Chart Statistics */}
        <div className="px-6 py-4 border-t border-border">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Day Range</span>
              <p className="font-medium">
                ${Math.min(...data.map(d => d.low)).toFixed(2)} - ${Math.max(...data.map(d => d.high)).toFixed(2)}
              </p>
            </div>
            <div>
              <span className="text-muted-foreground">Volume</span>
              <p className="font-medium">
                {data[data.length - 1]?.volume.toLocaleString()}
              </p>
            </div>
            <div>
              <span className="text-muted-foreground">Avg Volume</span>
              <p className="font-medium">
                {Math.floor(data.reduce((sum, d) => sum + d.volume, 0) / data.length).toLocaleString()}
              </p>
            </div>
            <div>
              <span className="text-muted-foreground">Market Status</span>
              <Badge variant="secondary" className="bg-success/10 text-success border-success/20">
                OPEN
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};