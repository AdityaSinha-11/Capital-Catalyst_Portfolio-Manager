import { LineChart, Line, ResponsiveContainer, XAxis, YAxis } from 'recharts';

// Mock chart data
const generateMockData = () => {
  const data = [];
  let basePrice = 100 + Math.random() * 200;
  
  for (let i = 0; i < 24; i++) {
    basePrice += (Math.random() - 0.5) * 10;
    data.push({
      time: i,
      price: Math.max(basePrice, 10)
    });
  }
  return data;
};

interface MiniChartProps {
  symbol: string;
  className?: string;
  isPositive?: boolean;
}

export const MiniChart = ({ symbol, className = "", isPositive = true }: MiniChartProps) => {
  const data = generateMockData();
  const color = isPositive ? 'hsl(var(--success))' : 'hsl(var(--destructive))';

  return (
    <div className={`h-16 w-24 ${className}`}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis hide />
          <YAxis hide />
          <Line 
            type="monotone" 
            dataKey="price" 
            stroke={color}
            strokeWidth={1.5}
            dot={false}
            activeDot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};