import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown, DollarSign, Activity } from "lucide-react";
import { PortfolioSummary as PortfolioSummaryType } from "@/types/stock";

interface PortfolioSummaryProps {
  summary: PortfolioSummaryType;
}

export const PortfolioSummary = ({ summary }: PortfolioSummaryProps) => {
  const isPositive = summary.total_pnl >= 0;
  const isDayPositive = summary.day_change >= 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <Card className="bg-card/50 backdrop-blur border-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Portfolio Value</p>
              <p className="text-2xl font-bold">${summary.total_value.toLocaleString()}</p>
            </div>
            <DollarSign className="h-8 w-8 text-primary" />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card/50 backdrop-blur border-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total Invested</p>
              <p className="text-2xl font-bold">${summary.total_invested.toLocaleString()}</p>
            </div>
            <Activity className="h-8 w-8 text-muted-foreground" />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card/50 backdrop-blur border-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total P&L</p>
              <p className={`text-2xl font-bold ${isPositive ? 'text-success' : 'text-destructive'}`}>
                {isPositive ? '+' : ''}${summary.total_pnl.toLocaleString()}
              </p>
              <p className={`text-sm ${isPositive ? 'text-success' : 'text-destructive'}`}>
                {isPositive ? '+' : ''}{summary.total_pnl_percent.toFixed(2)}%
              </p>
            </div>
            {isPositive ? (
              <TrendingUp className="h-8 w-8 text-success" />
            ) : (
              <TrendingDown className="h-8 w-8 text-destructive" />
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card/50 backdrop-blur border-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Day Change</p>
              <p className={`text-2xl font-bold ${isDayPositive ? 'text-success' : 'text-destructive'}`}>
                {isDayPositive ? '+' : ''}${summary.day_change.toLocaleString()}
              </p>
              <p className={`text-sm ${isDayPositive ? 'text-success' : 'text-destructive'}`}>
                {isDayPositive ? '+' : ''}{summary.day_change_percent.toFixed(2)}%
              </p>
            </div>
            {isDayPositive ? (
              <TrendingUp className="h-8 w-8 text-success" />
            ) : (
              <TrendingDown className="h-8 w-8 text-destructive" />
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};