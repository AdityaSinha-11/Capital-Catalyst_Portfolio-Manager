import { useState } from "react";
import { Instrument, TradeLog } from "@/types/stock";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  TrendingUp, 
  TrendingDown, 
  Trash2, 
  BarChart3,
  Plus 
} from "lucide-react";

interface HoldingsTableProps {
  instruments: Instrument[];
  tradeLogs: TradeLog[];
  onDeleteInstrument: (id: number) => void;
  onViewChart: (symbol: string) => void;
  onAddInstrument: () => void;
}

interface PortfolioHolding {
  instrument: Instrument;
  quantity: number;
  avgPrice: number;
  totalInvested: number;
  currentValue: number;
  pnl: number;
  pnlPercent: number;
}

export const HoldingsTable = ({ 
  instruments, 
  tradeLogs,
  onDeleteInstrument, 
  onViewChart, 
  onAddInstrument 
}: HoldingsTableProps) => {
  const [hoveredRow, setHoveredRow] = useState<number | null>(null);

  // Calculate portfolio holdings from instruments and trade logs
  const calculateHoldings = (): PortfolioHolding[] => {
    const holdings = new Map<number, PortfolioHolding>();

    // Process trade logs to calculate holdings
    tradeLogs.forEach((trade) => {
      try {
        const instrument = instruments.find(i => i.id === trade.instrument_id);
        if (!instrument) return;

        const existing = holdings.get(instrument.id);
        const tradeValue = trade.quantity * trade.price;

        if (existing) {
          if (trade.transaction_type === 'BUY') {
            existing.quantity += trade.quantity;
            existing.totalInvested += tradeValue;
          } else if (trade.transaction_type === 'SELL') {
            existing.quantity -= trade.quantity;
            existing.totalInvested -= tradeValue;
          }
        } else if (trade.transaction_type === 'BUY') {
          holdings.set(instrument.id, {
            instrument,
            quantity: trade.quantity,
            avgPrice: trade.price,
            totalInvested: tradeValue,
            currentValue: trade.quantity * Number(instrument.current_price),
            pnl: 0,
            pnlPercent: 0
          });
        }

        // Update P&L calculations
        const holding = holdings.get(instrument.id);
        if (holding && holding.quantity > 0) {
          holding.avgPrice = holding.totalInvested / holding.quantity;
          holding.currentValue = holding.quantity * Number(instrument.current_price);
          holding.pnl = holding.currentValue - holding.totalInvested;
          holding.pnlPercent = holding.totalInvested > 0 ? (holding.pnl / holding.totalInvested) * 100 : 0;
        }
      } catch (error) {
        console.error('Error processing trade:', trade, error);
      }
    });

    // Filter out holdings with zero quantity
    return Array.from(holdings.values()).filter(holding => holding.quantity > 0);
  };

  const holdings = calculateHoldings();

  if (holdings.length === 0) {
    return (
      <Card className="bg-card/50 backdrop-blur border-border">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
              <BarChart3 className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Start Your Investment Journey</h3>
              <p className="text-muted-foreground">Add your first instrument to begin tracking your portfolio</p>
            </div>
            <Button onClick={onAddInstrument} className="gap-2">
              <Plus className="h-4 w-4" />
              Add Your First Instrument
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card/50 backdrop-blur border-border">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Holdings</CardTitle>
        <Button onClick={onAddInstrument} size="sm" className="gap-2">
          <Plus className="h-4 w-4" />
          Add Instrument
        </Button>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border border-border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Symbol</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="text-right">Qty</TableHead>
                <TableHead className="text-right">Avg Price</TableHead>
                <TableHead className="text-right">LTP</TableHead>
                <TableHead className="text-right">P&L</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {holdings.map((holding) => {
                const isPnlPositive = holding.pnl >= 0;

                return (
                  <TableRow
                    key={holding.instrument.id}
                    className="hover:bg-secondary/30 transition-colors"
                    onMouseEnter={() => setHoveredRow(holding.instrument.id)}
                    onMouseLeave={() => setHoveredRow(null)}
                  >
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-primary">{holding.instrument.symbol}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground">{holding.instrument.name}</span>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {holding.instrument.type}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">{holding.quantity}</TableCell>
                    <TableCell className="text-right">₹{holding.avgPrice.toFixed(2)}</TableCell>
                    <TableCell className="text-right font-medium">
                      ₹{Number(holding.instrument.current_price).toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="space-y-1">
                        <div className={`font-medium ${isPnlPositive ? 'text-success' : 'text-destructive'}`}>
                          {isPnlPositive ? '+' : ''}₹{holding.pnl.toFixed(2)}
                        </div>
                        <Badge 
                          variant={isPnlPositive ? "secondary" : "destructive"}
                          className={`text-xs ${isPnlPositive ? 'bg-success/10 text-success border-success/20' : 'bg-destructive/10 text-destructive border-destructive/20'}`}
                        >
                          {isPnlPositive ? '+' : ''}{holding.pnlPercent.toFixed(2)}%
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className={`flex items-center justify-end gap-1 transition-opacity ${
                        hoveredRow === holding.instrument.id ? 'opacity-100' : 'opacity-0'
                      }`}>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onViewChart(holding.instrument.symbol)}
                          className="h-8 w-8 hover:bg-primary/10 hover:text-primary"
                        >
                          <BarChart3 className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onDeleteInstrument(holding.instrument.id)}
                          className="h-8 w-8 hover:bg-destructive/10 hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};