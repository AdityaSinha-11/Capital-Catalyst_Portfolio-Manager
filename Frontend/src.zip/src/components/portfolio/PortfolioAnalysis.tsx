import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";
import { TrendingUp, TrendingDown, Target, PieChart as PieChartIcon, BarChart3 } from "lucide-react";
import { Instrument, Goal, TradeLog } from "@/types/stock";

interface PortfolioAnalysisProps {
  instruments: Instrument[];
  goals: Goal[];
  tradeLogs: TradeLog[];
}

interface PortfolioHolding {
  instrument: Instrument;
  quantity: number;
  avgPrice: number;
  totalInvested: number;
  currentValue: number;
  pnl: number;
  pnlPercent: number;
}

export const PortfolioAnalysis = ({ instruments, goals, tradeLogs }: PortfolioAnalysisProps) => {
  // Calculate portfolio holdings from instruments and trade logs
  const calculateHoldings = (): PortfolioHolding[] => {
    const holdings = new Map<number, PortfolioHolding>();

    // Process trade logs to calculate holdings
    tradeLogs.forEach((trade) => {
      const instrument = instruments.find(i => i.id === trade.instrument_id);
      if (!instrument) return;

      const existing = holdings.get(instrument.id);
      const tradeValue = trade.quantity * trade.price;

      if (existing) {
        if (trade.transaction_type === 'BUY') {
          existing.quantity += trade.quantity;
          existing.totalInvested += tradeValue;
        } else if (trade.transaction_type === 'SELL') {
          existing.quantity -= trade.quantity;
          existing.totalInvested -= tradeValue;
        }
      } else if (trade.transaction_type === 'BUY') {
        holdings.set(instrument.id, {
          instrument,
          quantity: trade.quantity,
          avgPrice: trade.price,
          totalInvested: tradeValue,
          currentValue: trade.quantity * Number(instrument.current_price),
          pnl: 0,
          pnlPercent: 0
        });
      }

      // Update P&L calculations
      const holding = holdings.get(instrument.id);
      if (holding && holding.quantity > 0) {
        holding.avgPrice = holding.totalInvested / holding.quantity;
        holding.currentValue = holding.quantity * Number(instrument.current_price);
        holding.pnl = holding.currentValue - holding.totalInvested;
        holding.pnlPercent = holding.totalInvested > 0 ? (holding.pnl / holding.totalInvested) * 100 : 0;
      }
    });

    // Filter out holdings with zero quantity
    return Array.from(holdings.values()).filter(holding => holding.quantity > 0);
  };

  const holdings = calculateHoldings();

  // Calculate asset allocation
  const assetAllocation = holdings.reduce((acc, holding) => {
    acc[holding.instrument.type] = (acc[holding.instrument.type] || 0) + holding.currentValue;
    return acc;
  }, {} as Record<string, number>);

  const totalValue = Object.values(assetAllocation).reduce((sum, value) => sum + value, 0);

  const allocationData = Object.entries(assetAllocation).map(([type, value]) => ({
    name: type,
    value,
    percentage: (value / totalValue) * 100
  }));

  // Calculate top performers
  const topPerformers = holdings
    .sort((a, b) => b.pnlPercent - a.pnlPercent)
    .slice(0, 5);

  // Calculate goal progress
  const goalProgress = goals.map(goal => {
    const goalInvestments = holdings.filter(holding => 
      tradeLogs.some(trade => 
        trade.instrument_id === holding.instrument.id && 
        trade.goal_id === goal.id
      )
    );
    const currentAmount = goalInvestments.reduce((sum, holding) => 
      sum + holding.currentValue, 0
    );
    
    return {
      goal_id: goal.id,
      goal_name: goal.name,
      target_amount: goal.target_amount,
      current_amount: currentAmount,
      progress_percentage: Math.min((currentAmount / goal.target_amount) * 100, 100)
    };
  });

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#0088fe'];

  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString()}`;
  };

  if (holdings.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
              <BarChart3 className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">No Portfolio Data</h3>
              <p className="text-muted-foreground">Add some instruments and make trades to see portfolio analysis</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Portfolio Analysis</h2>
        <Badge variant="outline" className="text-sm">
          Total Value: {formatCurrency(totalValue)}
        </Badge>
      </div>

      {/* Asset Allocation */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChartIcon className="h-5 w-5" />
              Asset Allocation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={allocationData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percentage }) => `${name} ${percentage.toFixed(1)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {allocationData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatCurrency(value)} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-1 gap-2 mt-4">
              {allocationData.map((item, index) => (
                <div key={item.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    />
                    <span className="text-sm font-medium">{item.name}</span>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{formatCurrency(item.value)}</div>
                    <div className="text-xs text-muted-foreground">{item.percentage.toFixed(1)}%</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Top Performers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topPerformers.map((holding, index) => (
                <div key={holding.instrument.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/20">
                  <div>
                    <div className="font-semibold">{holding.instrument.symbol}</div>
                    <div className="text-sm text-muted-foreground">{holding.instrument.name}</div>
                    <Badge variant={holding.instrument.type === 'STOCK' ? 'default' : holding.instrument.type === 'MF' ? 'secondary' : 'outline'} className="text-xs mt-1">
                      {holding.instrument.type}
                    </Badge>
                  </div>
                  <div className="text-right">
                    <div className={`font-bold ${holding.pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {holding.pnl >= 0 ? '+' : ''}{formatCurrency(holding.pnl)}
                    </div>
                    <div className={`text-sm flex items-center gap-1 ${holding.pnlPercent >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {holding.pnlPercent >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                      {holding.pnlPercent >= 0 ? '+' : ''}{holding.pnlPercent.toFixed(2)}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Goal Progress */}
      {goalProgress.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Goal Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {goalProgress.map((goal) => (
                <div key={goal.goal_id} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <h4 className="font-semibold">{goal.goal_name}</h4>
                    <Badge variant={goal.progress_percentage >= 100 ? 'default' : 'secondary'}>
                      {goal.progress_percentage.toFixed(1)}%
                    </Badge>
                  </div>
                  <Progress value={goal.progress_percentage} className="h-2" />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Current: {formatCurrency(goal.current_amount)}</span>
                    <span>Target: {formatCurrency(goal.target_amount)}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};