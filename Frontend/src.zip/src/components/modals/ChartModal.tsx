import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TradingChart } from '@/components/charts/TradingChart';
import { useChartData } from '@/hooks/useChartData';
import { X, ExternalLink, Plus, Minus } from 'lucide-react';

interface ChartModalProps {
  isOpen: boolean;
  onClose: () => void;
  symbol: string;
  stockName?: string;
}

export const ChartModal = ({ isOpen, onClose, symbol, stockName }: ChartModalProps) => {
  const [selectedInterval, setSelectedInterval] = useState('1D');
  const { data, isLoading, intervals } = useChartData(symbol);

  const chartData = data[selectedInterval] || [];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl w-full h-[90vh] p-0">
        <DialogHeader className="px-6 py-4 border-b border-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <DialogTitle className="text-xl font-bold">
                {symbol} Chart
              </DialogTitle>
              {stockName && (
                <Badge variant="outline" className="text-xs">
                  {stockName}
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="gap-2">
                <Plus className="h-3 w-3" />
                Add to Watchlist
              </Button>
              <Button variant="outline" size="sm" className="gap-2">
                <ExternalLink className="h-3 w-3" />
                Full Screen
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="h-8 w-8"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-auto p-6">
          {isLoading ? (
            <div className="flex items-center justify-center h-96">
              <div className="text-center">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading chart data...</p>
              </div>
            </div>
          ) : (
            <TradingChart
              symbol={symbol}
              data={chartData}
              selectedInterval={selectedInterval}
              onIntervalChange={setSelectedInterval}
              intervals={intervals}
            />
          )}

          {/* Additional Analysis Section */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Key Statistics */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Key Statistics</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">52W High</span>
                    <span className="font-medium">$195.42</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">52W Low</span>
                    <span className="font-medium">$124.17</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Market Cap</span>
                    <span className="font-medium">$2.8T</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">P/E Ratio</span>
                    <span className="font-medium">28.7</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">EPS</span>
                    <span className="font-medium">$6.13</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Dividend</span>
                    <span className="font-medium">$0.94</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Technical Indicators */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Technical Indicators</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">RSI (14)</span>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">64.2</span>
                    <Badge variant="secondary" className="bg-warning/10 text-warning border-warning/20">
                      Neutral
                    </Badge>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">MACD</span>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">+1.24</span>
                    <Badge variant="secondary" className="bg-success/10 text-success border-success/20">
                      Bullish
                    </Badge>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">SMA (20)</span>
                  <span className="font-medium">$172.45</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">SMA (50)</span>
                  <span className="font-medium">$168.32</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};