import { useState } from "react";
import { Stock, StockSearchResult, Goal } from "@/types/stock";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, TrendingUp, Target } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AddStockModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddStock: (stock: Omit<Stock, 'id'>) => void;
  goals: Goal[];
}

// Mock search results
const mockSearchResults: StockSearchResult[] = [
  { symbol: "AAPL", name: "Apple Inc.", exchange: "NASDAQ", type: "STOCK", currency: "USD" },
  { symbol: "MSFT", name: "Microsoft Corporation", exchange: "NASDAQ", type: "STOCK", currency: "USD" },
  { symbol: "GOOGL", name: "Alphabet Inc.", exchange: "NASDAQ", type: "STOCK", currency: "USD" },
  { symbol: "TSLA", name: "Tesla, Inc.", exchange: "NASDAQ", type: "STOCK", currency: "USD" },
  { symbol: "NVDA", name: "NVIDIA Corporation", exchange: "NASDAQ", type: "STOCK", currency: "USD" },
  { symbol: "AMZN", name: "Amazon.com, Inc.", exchange: "NASDAQ", type: "STOCK", currency: "USD" },
  { symbol: "META", name: "Meta Platforms, Inc.", exchange: "NASDAQ", type: "STOCK", currency: "USD" },
  { symbol: "NFLX", name: "Netflix, Inc.", exchange: "NASDAQ", type: "STOCK", currency: "USD" },
  { symbol: "HDFCMF", name: "HDFC Large Cap Fund", exchange: "NSE", type: "MF", currency: "INR" },
  { symbol: "ICICIMF", name: "ICICI Prudential Bluechip Fund", exchange: "NSE", type: "MF", currency: "INR" },
  { symbol: "SBIMF", name: "SBI Large & Midcap Fund", exchange: "NSE", type: "MF", currency: "INR" },
  { symbol: "GOLD", name: "Gold ETF", exchange: "NSE", type: "GOLD", currency: "INR" },
  { symbol: "GOLDBEESN", name: "Nippon India ETF Gold BeES", exchange: "NSE", type: "GOLD", currency: "INR" },
  { symbol: "AXISGOLD", name: "Axis Gold ETF", exchange: "NSE", type: "GOLD", currency: "INR" },
];

export const AddStockModal = ({ isOpen, onClose, onAddStock, goals }: AddStockModalProps) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStock, setSelectedStock] = useState<StockSearchResult | null>(null);
  const [quantity, setQuantity] = useState("");
  const [price, setPrice] = useState("");
  const [purchaseDate, setPurchaseDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [selectedGoalId, setSelectedGoalId] = useState<string>("none");
  const { toast } = useToast();

  const filteredResults = mockSearchResults.filter(
    (stock) =>
      stock.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      stock.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSelectStock = (stock: StockSearchResult) => {
    setSelectedStock(stock);
    setSearchQuery(stock.symbol);
    // Mock current price
    const mockPrice = (Math.random() * 500 + 50).toFixed(2);
    setPrice(mockPrice);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedStock || !quantity || !price || !purchaseDate) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    const stock: Omit<Stock, 'id'> = {
      symbol: selectedStock.symbol,
      name: selectedStock.name,
      type: selectedStock.type,
      quantity: parseInt(quantity),
      purchase_price: parseFloat(price),
      purchase_date: purchaseDate,
      goal_id: selectedGoalId && selectedGoalId !== "none" ? parseInt(selectedGoalId) : undefined,
    };

    onAddStock(stock);
    
    // Reset form
    setSearchQuery("");
    setSelectedStock(null);
    setQuantity("");
    setPrice("");
    setPurchaseDate(new Date().toISOString().split('T')[0]);
    setSelectedGoalId("none");
    
    onClose();
    
    toast({
      title: "Success",
      description: `Added ${stock.symbol} to your portfolio`,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Add Investment to Portfolio
          </DialogTitle>
          <DialogDescription>
            Search for an investment, set the quantity and price, and optionally link it to a financial goal.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Investment Search */}
          <div className="space-y-2">
            <Label htmlFor="stock-search">Search Investment</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="stock-search"
                placeholder="Search stocks, mutual funds, or gold..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            {searchQuery && !selectedStock && (
              <div className="border border-border rounded-md p-2 max-h-48 overflow-y-auto">
                {filteredResults.length > 0 ? (
                  <div className="space-y-1">
                    {filteredResults.map((stock) => (
                      <button
                        key={stock.symbol}
                        type="button"
                        onClick={() => handleSelectStock(stock)}
                        className="w-full text-left p-2 rounded hover:bg-secondary/50 transition-colors"
                      >
                         <div className="flex items-center justify-between">
                           <div>
                             <span className="font-mono font-bold text-primary">
                               {stock.symbol}
                             </span>
                             <span className="ml-2 text-sm text-muted-foreground">
                               {stock.name}
                             </span>
                           </div>
                           <div className="flex gap-1">
                             <Badge variant={stock.type === 'STOCK' ? 'default' : stock.type === 'MF' ? 'secondary' : 'outline'} className="text-xs">
                               {stock.type}
                             </Badge>
                             <Badge variant="outline" className="text-xs">
                               {stock.exchange}
                             </Badge>
                           </div>
                         </div>
                      </button>
                    ))}
                  </div>
                 ) : (
                   <p className="text-sm text-muted-foreground p-2">No investments found</p>
                 )}
              </div>
            )}
          </div>

          {selectedStock && (
            <div className="p-3 border border-border rounded-md bg-secondary/20">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-mono font-bold text-primary text-lg">
                    {selectedStock.symbol}
                  </span>
                   <p className="text-sm text-muted-foreground">
                     {selectedStock.name}
                   </p>
                 </div>
                 <div className="flex gap-1">
                   <Badge variant={selectedStock.type === 'STOCK' ? 'default' : selectedStock.type === 'MF' ? 'secondary' : 'outline'}>
                     {selectedStock.type}
                   </Badge>
                   <Badge variant="outline">{selectedStock.exchange}</Badge>
                 </div>
              </div>
            </div>
          )}

          {/* Quantity and Price */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                id="quantity"
                type="number"
                placeholder="Enter quantity"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                min="1"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="price">Price per Unit</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                placeholder="Enter price"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                min="0"
              />
            </div>
          </div>

          {/* Goal Selection */}
          <div className="space-y-2">
            <Label htmlFor="goal-select" className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              Investment Goal (Optional)
            </Label>
            <Select value={selectedGoalId} onValueChange={setSelectedGoalId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a goal or leave blank" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No specific goal</SelectItem>
                {goals.map((goal) => (
                  <SelectItem key={goal.id} value={goal.id.toString()}>
                    {goal.name} (Target: ₹{goal.target_amount.toLocaleString()})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Purchase Date */}
          <div className="space-y-2">
            <Label htmlFor="purchase-date">Purchase Date</Label>
            <Input
              id="purchase-date"
              type="date"
              value={purchaseDate}
              onChange={(e) => setPurchaseDate(e.target.value)}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={!selectedStock || !quantity || !price}
              className="flex-1"
            >
              Add to Portfolio
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};