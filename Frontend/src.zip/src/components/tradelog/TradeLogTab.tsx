import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { TrendingUp, TrendingDown, Calendar, Target, Activity } from "lucide-react";
import { TradeLog } from "@/types/stock";

interface TradeLogTabProps {
  tradeLogs: TradeLog[];
}

export const TradeLogTab = ({ tradeLogs }: TradeLogTabProps) => {
  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString()}`;
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'STOCK':
        return <TrendingUp className="h-4 w-4" />;
      case 'MF':
        return <Target className="h-4 w-4" />;
      case 'GOLD':
        return <Activity className="h-4 w-4" />;
      default:
        return <TrendingUp className="h-4 w-4" />;
    }
  };

  const getTypeBadgeVariant = (type: string) => {
    switch (type) {
      case 'STOCK':
        return 'default';
      case 'MF':
        return 'secondary';
      case 'GOLD':
        return 'outline';
      default:
        return 'default';
    }
  };

  if (tradeLogs.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Activity className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Trade History</h3>
          <p className="text-muted-foreground text-center">
            Your trading activity will appear here once you start making transactions.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Trade Log History</h2>
        <Badge variant="outline" className="text-sm">
          {tradeLogs.length} Total Transactions
        </Badge>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Recent Transactions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date & Time</TableHead>
                <TableHead>Instrument</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Goal</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tradeLogs.map((trade) => (
                <TableRow key={trade.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">
                        {formatDateTime(trade.created_at)}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-mono font-bold">
                        {trade.instrument_symbol}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {trade.instrument_name}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={getTypeBadgeVariant(trade.instrument_type)} className="flex items-center gap-1 w-fit">
                      {getTypeIcon(trade.instrument_type)}
                      {trade.instrument_type}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant={trade.transaction_type === 'BUY' ? 'default' : 'destructive'}
                      className="flex items-center gap-1 w-fit"
                    >
                      {trade.transaction_type === 'BUY' ? (
                        <TrendingUp className="h-3 w-3" />
                      ) : (
                        <TrendingDown className="h-3 w-3" />
                      )}
                      {trade.transaction_type}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-medium">
                    {trade.quantity}
                  </TableCell>
                  <TableCell>
                    {formatCurrency(trade.price)}
                  </TableCell>
                  <TableCell className="font-bold">
                    {formatCurrency(trade.total_amount)}
                  </TableCell>
                  <TableCell>
                    {trade.goal_name ? (
                      <Badge variant="outline" className="flex items-center gap-1 w-fit">
                        <Target className="h-3 w-3" />
                        {trade.goal_name}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground text-sm">-</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};