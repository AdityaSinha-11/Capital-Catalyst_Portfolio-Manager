import { useState } from "react";
import { Header } from "@/components/layout/Header";
import { PortfolioSummary } from "@/components/portfolio/PortfolioSummary";
import { HoldingsTable } from "@/components/portfolio/HoldingsTable";
import { AddStockModal } from "@/components/modals/AddStockModal";
import { ChartModal } from "@/components/modals/ChartModal";
import { GoalsTab } from "@/components/goals/GoalsTab";
import { TradeLogTab } from "@/components/tradelog/TradeLogTab";
import { PortfolioAnalysis } from "@/components/portfolio/PortfolioAnalysis";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useInstruments } from "@/hooks/useInstruments";
import { useGoals } from "@/hooks/useGoals";
import { useTradeLogs } from "@/hooks/useTradeLogs";
import { useToast } from "@/hooks/use-toast";
import ErrorBoundary from "@/components/ErrorBoundary";

const Index = () => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isChartModalOpen, setIsChartModalOpen] = useState(false);
  const [selectedSymbol, setSelectedSymbol] = useState("");
  const [selectedStockName, setSelectedStockName] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("portfolio");
  
  const { instruments, addInstrument, deleteInstrument, buyInstrument, sellInstrument } = useInstruments();
  const { goals, addGoal, deleteGoal } = useGoals();
  const { tradeLogs, refetch: refetchTradeLogs } = useTradeLogs();
  const { toast } = useToast();

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    console.log("Searching for:", query);
  };

  const handleDeleteInstrument = async (id: number) => {
    const instrument = instruments.find(i => i.id === id);
    if (instrument) {
      try {
        // First try to delete without cascade
        await deleteInstrument(id);
        toast({
          title: "Instrument Removed",
          description: `${instrument.symbol} has been removed from your portfolio`,
        });
      } catch (error) {
        // Extract the actual error message from the backend response
        let errorMessage = 'Failed to delete instrument';
        if (error && typeof error === 'object' && 'response' in error && error.response?.data?.error) {
          errorMessage = error.response.data.error;
        } else if (error instanceof Error) {
          errorMessage = error.message;
        }
        
        // If it fails due to trade logs, ask user if they want to cascade delete
        if (errorMessage.includes('trade history')) {
          const confirmed = window.confirm(
            `${instrument.symbol} has trade history. Do you want to delete the instrument and all its associated trade logs? This action cannot be undone.`
          );
          
          if (confirmed) {
            try {
              await deleteInstrument(id, true); // Use cascade delete
              toast({
                title: "Instrument Removed",
                description: `${instrument.symbol} and all its trade history have been removed from your portfolio`,
              });
            } catch (cascadeError) {
              let cascadeErrorMessage = 'Failed to delete instrument';
              if (cascadeError && typeof cascadeError === 'object' && 'response' in cascadeError && cascadeError.response?.data?.error) {
                cascadeErrorMessage = cascadeError.response.data.error;
              } else if (cascadeError instanceof Error) {
                cascadeErrorMessage = cascadeError.message;
              }
              toast({
                title: "Error",
                description: cascadeErrorMessage,
                variant: "destructive",
              });
            }
          }
        } else {
          toast({
            title: "Error",
            description: errorMessage,
            variant: "destructive",
          });
        }
      }
    }
  };

  const handleAddInstrument = async (stockData: any) => {
    try {
      // First, add the instrument to the database
      const instrumentData = {
        symbol: stockData.symbol,
        name: stockData.name,
        type: stockData.type,
        current_price: stockData.purchase_price // Use purchase price as current price initially
      };
      
      const newInstrument = await addInstrument(instrumentData);
      
      // Then create a buy trade log for this instrument
      await buyInstrument(newInstrument.id, {
        quantity: stockData.quantity,
        price: stockData.purchase_price,
        goal_id: stockData.goal_id
      });
      
      // Refresh trade logs
      await refetchTradeLogs();
      
      toast({
        title: "Success",
        description: `${stockData.symbol} added to portfolio successfully`,
      });
    } catch (error) {
      let errorMessage = 'Failed to add instrument';
      if (error && typeof error === 'object' && 'response' in error && error.response?.data?.error) {
        errorMessage = error.response.data.error;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const handleViewChart = (symbol: string) => {
    const instrument = instruments.find(i => i.symbol === symbol);
    setSelectedSymbol(symbol);
    setSelectedStockName(instrument?.name || "");
    setIsChartModalOpen(true);
  };

  const handleMenuToggle = () => {
    console.log("Menu toggled");
  };

  // Calculate portfolio summary from instruments and trade logs
  const calculatePortfolioSummary = () => {
    // This would need to be calculated based on trade logs and current instrument prices
    // For now, returning a basic structure
    return {
      total_value: 0,
      total_invested: 0,
      total_pnl: 0,
      total_pnl_percent: 0,
      day_change: 0,
      day_change_percent: 0
    };
  };

  const portfolioSummary = calculatePortfolioSummary();

  return (
    <div className="min-h-screen bg-background">
      <Header 
        onMenuToggle={handleMenuToggle}
        onSearch={handleSearch}
      />
      <ErrorBoundary>
        <main className="container mx-auto px-4 py-8 space-y-8">
          <PortfolioSummary summary={portfolioSummary} />
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
              <TabsTrigger value="goals">Goals</TabsTrigger>
              <TabsTrigger value="tradelog">Trade Log</TabsTrigger>
              <TabsTrigger value="analysis">Analysis</TabsTrigger>
            </TabsList>
            
            <TabsContent value="portfolio" className="space-y-6">
              <HoldingsTable 
                instruments={instruments}
                tradeLogs={tradeLogs}
                onDeleteInstrument={handleDeleteInstrument}
                onViewChart={handleViewChart}
                onAddInstrument={() => setIsAddModalOpen(true)}
              />
            </TabsContent>
            
            <TabsContent value="goals" className="space-y-6">
              <GoalsTab 
                goals={goals}
                onAddGoal={addGoal}
                onDeleteGoal={deleteGoal}
              />
            </TabsContent>
            
            <TabsContent value="tradelog" className="space-y-6">
              <TradeLogTab tradeLogs={tradeLogs} />
            </TabsContent>
            
            <TabsContent value="analysis" className="space-y-6">
              <PortfolioAnalysis instruments={instruments} goals={goals} tradeLogs={tradeLogs} />
            </TabsContent>
          </Tabs>
        </main>
      </ErrorBoundary>
      
      <AddStockModal 
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddStock={handleAddInstrument}
        goals={goals}
      />
      
      <ChartModal 
        isOpen={isChartModalOpen}
        onClose={() => setIsChartModalOpen(false)}
        symbol={selectedSymbol}
        stockName={selectedStockName}
      />
    </div>
  );
};

export default Index;