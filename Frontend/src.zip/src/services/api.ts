import axios from 'axios';

const API_BASE_URL = 'http://localhost:9001';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Instruments API
export const instrumentsApi = {
  getAll: () => api.get('/instruments'),
  getById: (id: number) => api.get(`/instruments/${id}`),
  create: (data: { symbol: string; name: string; type: 'STOCK' | 'MF' | 'GOLD'; current_price: number }) =>
    api.post('/instruments', data),
  update: (id: number, data: { symbol: string; name: string; type: 'STOCK' | 'MF' | 'GOLD'; current_price: number }) =>
    api.put(`/instruments/${id}`, data),
  delete: (id: number, cascade?: boolean) => {
    const url = cascade ? `/instruments/${id}?cascade=true` : `/instruments/${id}`;
    return api.delete(url);
  },
  buy: (id: number, data: { quantity: number; price: number; goal_id?: number }) =>
    api.post(`/instruments/${id}/buy`, data),
  sell: (id: number, data: { quantity: number; price: number; goal_id?: number }) =>
    api.post(`/instruments/${id}/sell`, data),
};

// Goals API
export const goalsApi = {
  getAll: () => api.get('/goals'),
  getById: (id: number) => api.get(`/goals/${id}`),
  create: (data: { name: string; target_amount: number }) =>
    api.post('/goals', data),
  update: (id: number, data: { name: string; target_amount: number }) =>
    api.put(`/goals/${id}`, data),
  delete: (id: number) => api.delete(`/goals/${id}`),
};

// Trade Log API
export const tradeLogApi = {
  getAll: () => api.get('/trade-log'),
};

export default api; 