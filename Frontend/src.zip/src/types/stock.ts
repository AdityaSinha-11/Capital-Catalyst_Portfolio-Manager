export type InstrumentType = 'STOCK' | 'MF' | 'GOLD';

export interface Instrument {
  id: number;
  symbol: string;
  name: string;
  type: InstrumentType;
  current_price: number;
  created_at: string;
  updated_at: string;
}

export interface Stock {
  id?: number;
  symbol: string;
  name: string;
  type: InstrumentType;
  quantity: number;
  purchase_price: number;
  purchase_date: string;
  current_price?: number;
  change?: number;
  change_percent?: number;
  goal_id?: number;
}

export interface Goal {
  id: number;
  name: string;
  target_amount: number;
  current_amount: number;
  created_at: string;
}

export interface TradeLog {
  id: number;
  instrument_id: number;
  instrument_symbol: string;
  instrument_name: string;
  instrument_type: InstrumentType;
  goal_id?: number;
  goal_name?: string;
  transaction_type: 'BUY' | 'SELL';
  quantity: number;
  price: number;
  total_amount: number;
  created_at: string;
}

export interface StockSearchResult {
  symbol: string;
  name: string;
  exchange: string;
  type: InstrumentType;
  currency: string;
}

export interface ChartData {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface PortfolioSummary {
  total_value: number;
  total_invested: number;
  total_pnl: number;
  total_pnl_percent: number;
  day_change: number;
  day_change_percent: number;
}

export interface PortfolioAnalysis {
  asset_allocation: {
    STOCK: { value: number; percentage: number };
    MF: { value: number; percentage: number };
    GOLD: { value: number; percentage: number };
  };
  top_performers: Stock[];
  goal_progress: {
    goal_id: number;
    goal_name: string;
    target_amount: number;
    current_amount: number;
    progress_percentage: number;
  }[];
}